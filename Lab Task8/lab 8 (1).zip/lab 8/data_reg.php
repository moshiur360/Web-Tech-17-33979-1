<?php





?><!DOCTYPE html>
<html>

<head>
    <title align="center">Donates Required Information</title>
</head>

<body style="background-color:#ebebeb">

    <form action="">

        <div>


            <table align="center">
                <tr>

                    <td align="left" colspan=""="2">
                        <h1 style="color:green" align="left"><b>Donar Informations</b></h1>
                    </td>
                </tr>

                <tr>
                    <td align="right"> <label> <b>First Name </b> </label> </td>
                    <td><?php echo $_POST["fname"] ?> </td>
                    
                </tr>

                <tr>
                    <td align="right"> <label> <b>Last Name </b> </label> </td>
                    <td> <?php echo $_POST["lname"] ?> </td>
                    
                </tr>

                <tr>
                    <td align="right"> <label> <b>Company </b> </label> </td>
                    <td> <?php echo $_POST["company"] ?> </td>

                    
                </tr>

                <tr>
                    <td align="right"> <label> <b>Address 1 </b> </label> </td>
                    <td> <?php echo $_POST["add1"] ?> </td>
                    
                </tr>

                <tr>
                    <td align="right"> <label> <b>Address 2 </b> </label> </td>
                    <td> <?php echo $_POST["add2"] ?> </td>
                   
                </tr>

                <tr>
                    <td align="right"> <label> <b>City </b> </label> </td>
                    <td> <?php echo $_POST["city"] ?> </td>
                    
                </tr>

                <tr>
                    <td align="right"> <label><b>State <b /></label> </td>
                    <td> <?php echo $_POST["state"] ?> </td>
                    
                    
                </tr>

                <tr>
                    <td align="right"> <label> <b>Zip Code </b> </label> </td>
                    <td> <?php echo $_POST["zcode"] ?> </td>
                    
                    
                </tr>

                <tr>
                    <td align="right"> <label align="right"><b>Country </b></label> </td>
                    <td> <?php echo $_POST["country"] ?> </td>
                    
                </tr>


                <tr>
                    <td align="right"> <label><b>Phone </b></label> </td>
                    <td> <?php echo $_POST["phone"] ?> </td>
                   
                </tr>

                <tr>
                    <td align="right"> <label><b>Fax </b></label> </td>
                    <td> <?php echo $_POST["fax"] ?> </td>
                    
                </tr>

                <tr>
                    <td align="right"> <label><b>E-mail </b></label> </td>
                    <td> <?php echo $_POST["email"] ?> </td>
                    
                </tr>

                <tr>
                    <td align="right"> <label> <b>Donation Amount </b> </label> </td>
                    <td> <?php echo $_POST["donation"] ?> </td>
                    
                </tr>

                <tr>
                    <td align="right"> <label>(Check a button or type in your amount)</label> </td>
                    
                </tr>

                <tr>
                    <td align="right"><b> <label>Recurring Donation </label></b> </td>
                    
                </tr>

                <tr>
                    <td align="right"> <label>(Check if yes)</label> </td>
                </tr>

                <tr>
                    <td></td>
                    <td> <label> Monthly Credit Card $</label>
                         For  Months</td>
                </tr>





                <tr>
                    <td align="left" colspan=""="2">
                        <h1 style="color:red"><b>Honorarium and Memorial Donation Information</b></h1>
                    </td>
                </tr>


                <tr>
                    <td align="right"> <label> <b>I would like to make this <br> donation </b></label> </td>
                    <td>  To Honor
                    </td>
                </tr>


                <tr>
                    <td></td>
                    <td>  In Memory Of
                    </td>
                </tr>

                <tr>
                    <td align="right"> <label> <b>Name </b> </label> </td>
                    <td> > </td>
                </tr>

                <tr>
                    <td align="right"> <label> <b>Acknowledge Donation to</b> </label> </td>
                    <td>  </td>
                </tr>

                <tr>
                    <td align="right"> <label> <b>Address </b> </label> </td>
                    <td>  </td>
                </tr>

                <tr>
                    <td align="right"> <label> <b>City </b> </label> </td>
                    <td>  </td>
                </tr>

                <tr>
                    <td align="right"> <label><b>State <b /></label> </td>
                    
                </tr>

                <tr>
                    <td align="right"> <label> <b>Zip </b> </label> </td>
                    <td>  </td>
                </tr>

                <tr>
                    <td align="left" colspan=""="2">
                        <h1 style="color:red"><b>Additional Information</b></h1>
                    </td>
                </tr>

                <tr>
                    <td align="left" colspan=""=""><label>Please enter your name, company or organization as you would
                            like it to appear in our publications: </label> </td>
                </tr>


                <tr>
                    <td align="right"> <label> <b>Name </b> </label> </td>
                    
                </tr>


                <tr>
                    <td align="left" colspan="">
                        <input type="checkbox" value=""> I would like my gift to remain anonymous.
                    </td>
                </tr>
                <tr>
                    <td align="left" colspan="">
                        <input type="checkbox" value=""> My employer offers a matching gift program.I will mail the
                        matching gift form.
                    </td>
                </tr>

                <tr>
                    <td align="left" colspan="">
                        <input type="checkbox" value=""> Please save the cost of acknowledging this gift by not mailing
                        a thank you letter.
                    </td>
                </tr>


                <tr>
                    <td align="right"><label><b>Comments </b><br>
                            (please type any question or feedback <br>here)
                        </label> </td>
                    <td>  </td>
                </tr>

                <tr>
                    <td align="right"><label><b>How may we contact you?</b></label></td>
                    
                </tr>

                <tr>
                    <td></td>
                    
                </tr>

                <tr>
                    <td></td>
                    
                </tr>

                <tr>
                    <td></td>
                    
                </tr>

                <tr>
                    <td align="left" colspan=""=""><label>I would like to receive newsletters and Information about
                            special events by: </label> </td>
                </tr>
                <tr>
                    <td></td>
                    
                </tr>


                <tr>
                    <td></td>
                   
                </tr>

                <tr>
                    <td align="left" colspan=""> I would like information about
                        volunteerning with the</td>
                </tr>

                <tr>
                    <td align="left" colspan="2"></td>
                </tr>
                <tr>
                    <td align="right">  </td>
                    <td align="left">  </td>
                </tr>

            </table>
        </div>

    </form>



</body>

</html>