<?php 
session_start();

if($_SESSION['session'] == "php-learn"){
     session_destroy();

    header("location: ../view/login.php?msg=you-loged_out");
}else{
    header("location: ../view/login.php?msg=you-are-not-login");
}



?>