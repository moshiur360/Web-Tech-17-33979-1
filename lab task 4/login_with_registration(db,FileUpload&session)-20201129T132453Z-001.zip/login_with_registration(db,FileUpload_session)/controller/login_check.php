<?php 
require('../database/db.php');
session_start();

$name = $_POST["username"];
$password = $_POST["password"];
//$hash_password =  password_hash($password , PASSWORD_BCRYPT);

if(isset($_REQUEST["submit"])){
    if( $name != null && $password != null ){
        $sql = "SELECT * FROM `user` WHERE username='$name'";
        $result = mysqli_query($conn , $sql);

  if($result != null){
    
     while($row = mysqli_fetch_assoc($result)){
         if($row['username'] == $name){
            //$pass = password_hash($row['password'], PASSWORD_DEFAULT);
             if(md5($password) == $row['password']){
              //  die( 'Password is valid!');

                $_SESSION['session'] = "php-learn";
                header('location: ../view/home.php?msg=you-are-logged-in' . "$name");
             }else{
                // echo $password . "<br>";
                // echo $pass;
                //die( 'Password is invalid!');
                header('location: ../view/login.php?msg=invalid-creadiantial');
            }
                     
        }else{
            header('location: ../view/login.php?msg=invalid-creadiantial');
        }
     }
  }else{
    $error = mysqli_error($conn);
    header('location: ../view/login.php?msg=' . "$error");
  }  

    }else{
        header('location: ../view/login.php?msg=field-empty');
    }
}

mysqli_close($conn);
?>