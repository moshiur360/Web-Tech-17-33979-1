<?php
require('../database/db.php');
session_start();

if($_SESSION["session"] == "php-learn"){
    $id = $_REQUEST["userid"]; 
	 
    $sql = "DELETE  FROM user WHERE  id='$id' ";

    $result = mysqli_query($conn , $sql);
    if($result != null){
        header('location: ../view/home.php?msg=user-delete');
    }else {
        $error = mysqli_error($conn);
        header('location: ../view/home.php?msg='. "$error");
    }

}else {
    header('location: ../view/login.php?msg=invalid-creadiantial');
}

mysqli_close($conn);
?>