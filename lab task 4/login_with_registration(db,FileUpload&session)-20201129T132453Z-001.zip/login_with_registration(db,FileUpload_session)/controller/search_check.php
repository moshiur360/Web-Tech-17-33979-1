<?php 
require('../database/db.php');
session_start();

if($_SESSION['session'] == "php-learn"){
    
    if(isset($_REQUEST["search"])){
    
        $search_string =  trim($_REQUEST["search_string"]);
        
    
        if($search_string != null){
           
            $sql = "SELECT * FROM `user` WHERE username LIKE '%$search_string%' OR email LIKE '%$search_string%' ";
            $result = mysqli_query($conn , $sql);
    
            if(mysqli_num_rows($result) > 0){
        
                    $search_user = mysqli_fetch_all($result , 1);
                    $_SESSION['search_user'] = $search_user;
                    //print_r($search_user);die();
                    header('location: ../view/home.php?search_user=' . "$search_user" . "&search_string_result=" . $search_string);
                                
                }else{
                    
                    header('location: ../view/home.php?msg=no-data-found' . "&search_string_result=" . $search_string);
                  }
    
             }else{
                header('location: ../view/home.php?msg=search-field-empty');
            }
        
        }

}else{
    header('location: ../view/login.php?msg=invalid-creadiantial');
}



mysqli_close($conn);
?>