<?php
require('../database/db.php');

if(isset($_POST["submit"])){

    $name     = $_POST["username"];
    $email    = $_POST["email"];
    $password = $_POST["password"];
    $password = md5($password); //password hase making
    $gender   = $_POST["gender"];
    $image    = $_FILES["image"];

    if($name != null && $email != null && $password != null && $gender != null && $image != null){
        
        $file_data = explode('.', $image['name']);
        $file_exe = end($file_data);
        if(!in_array($file_exe , ['jpg'] , true)){
            //die($file_exe);
            header('location: ../view/rege.php?msg=is-not-a-valid-file');
        
        }
        
        $file_name = uniqid('PP_' , true) . '.' . $file_exe;
        $file_path = "../upload/user/" . $file_name;
        
        $upload = move_uploaded_file($image['tmp_name'] , $file_path );
        
        if($upload){
            
            if($conn){
                $sql = " INSERT INTO user(id , username , email , password , gender , image ) VALUES ( '' , '$name' , '$email' , '$password' , '$gender' , '$file_name' ) ";                 
    
                $result = mysqli_query($conn , $sql);
               
                if($result != null){
                    header('location: ../view/login.php?msg=user-registration-completed');
                    
                }else{
                    
                    header('location: ../view/rege.php?msg=file-not-found' );
                }                        
            }    
        }else{
            header('location: ../view/rege.php?msg=' . "$error"  );

        }
    }else{
        header('location: ../view/rege.php?msg=fild-empty');
    }

mysqli_close($conn);

}

?>