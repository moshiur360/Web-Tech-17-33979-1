<?php
require('../database/db.php');

if(isset($_POST["submit"])){

    $id = $_POST["id"];
    $name = $_POST["username"];
    $email = $_POST["email"];
    $password = md5($_POST["password"]);
    $gender = $_POST["gender"];
    $a = $_FILES["image"];
    
    //print_r(); die();
    if($a['size'] != 0){
        $image = $_FILES["image"];
        
        $file_data = explode('.', $image['name']);
        $file_exe = end($file_data);
        $file_name = uniqid('PP_' , true) . '.' . $file_exe;
        $file_path = "../upload/user/" . $file_name;
        $upload = move_uploaded_file($image['tmp_name'] , $file_path );
    }else{
        $file_name = $_POST["old_image"];
    }
    

    if($id != null && $name != null && $email != null && $password != null && $gender != null && $file_name != null){
        
        if($conn){
            $sql = " UPDATE  user SET username ='$name' , password='$password' , email='$email' , gender='$gender' , image='$file_name' where id='$id' ";                 

            $result = mysqli_query($conn , $sql);
           
            if($result != null){
                header('location: ../view/home.php?msg=user-update-completed');

                
            }else{
                $error = mysqli_error($conn);
                header('location: ../view/home.php?msg=' . "$error"  );
            }                        
        }else {
                $error = mysqli_connect_error($conn);
                header('location: ../view/home.php?msg=' . "$error"  );
        }

    }else{
        header('location: ../view/edit.php?msg=fild-empty');
    }

mysqli_close($conn);

}

?>