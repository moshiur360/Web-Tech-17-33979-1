<?php 
require('../database/db.php');
session_start();

echo "<a href='../controller/logout.php'> logout</a>";
echo "<a href='../view/home.php'> back</a> <br/><br/>";

$file_path = "C:/xampp/htdocs/Learn/PHP/login_system/login_with_registration(db,FileUpload&session)/upload/user/";

if($_SESSION["session"] == "php-learn"){
	 
	$id = $_REQUEST["userid"]; 
	 
    $sql = "SELECT * FROM user WHERE  id='$id' ";

	$result = mysqli_query($conn , $sql);
	
	if($result != null){
		$row = mysqli_fetch_array($result);
			
		    $id = $row['id'];	
		    $name = $row['username'];
			$password = md5($row['password']);
			$email = $row['email'];
			$gender = $row['gender'];
			$image  = $row['image'];
		
	}else{
		echo "data not edit".mysqli_error($conn);
	}
		 
  }else {
	header('location: ../view/login.php?msg=invalid-creadiantial');
  }

mysqli_close($conn);
?>


<!DOCTYPE html>
<html>
<head>
	<title>edit</title>
</head>
<body>
	<fieldset>
	<legend>edit</legend>
		<form method="post" action="../controller/edit_check.php" enctype="multipart/form-data">
		   <input type="hidden" name="id" value="<?php echo $id ?>"/><br/>
            User Name : <input type="text" name="username" value="<?php echo $name; ?>"/><br/>
            Email     : <input type="text" name="email" value="<?php echo $email; ?>"/><br/>
			Password  : <input type="password" name="password" value="<?php echo $password; ?>"/><br/>
			Image     : <input type="file" name="image"/> <br/>
			            <input type="hidden" name="old_image" value="<?php echo $image; ?>" />
					    <img src="<?php echo $file_path.$image; ?>" width="100px" height="50px" /> </a> <br/>
			Gender  : 
			<input type="radio" name="gender" value="male" <?php if($gender == "male") { echo "checked";}?>  />Male 
			<input type="radio" name="gender" value="female" <?php if($gender == "female") { echo "checked";}?> />Female 
			<input type="radio" name="gender" value="other" <?php if($gender == "other") { echo "checked";}?> />Other <br/>
			<input type="submit" name="submit" value="Submit"/>
		</form>
	</fieldset>
</body>
</html>