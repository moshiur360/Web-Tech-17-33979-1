<?php 
if(isset($_REQUEST["msg"])){

    $msg = $_REQUEST["msg"];
    
    if($msg == "user-update-completed"){
           echo $msg;
    }elseif ($msg == "field-empty") {
           echo $msg;
    }elseif ($msg == "user-delete") {
           echo $msg;
    }elseif($msg == "search-field-empty"){
           echo $msg;
    }elseif ($msg == "no-data-found") {
           echo $msg;
    }
    else{
		echo $msg;
	}
}

?>


<?php 
require('../database/db.php');
session_start();

$file_path = "../upload/user/";

if($_SESSION['session'] == "php-learn"){
    echo "<b>HOME</b> <br/><br/>";
    echo "<a href='../controller/logout.php'> logout</a> <br/><br/>";

    $sql = "SELECT * from user";

    $result = mysqli_query($conn , $sql);
    $row = mysqli_fetch_all($result , 1);

}else{
    header('location: ../view/login.php?msg=invalid-creadiantial');
}

mysqli_close($conn);
?>

<html>
<head>
	<title> HOME</title>
</head>
<body>
             <form method="post" action="../controller/search_check.php">
              search a user:<input type="text" name="search_string" value="<?php echo $_REQUEST["search_string_result"] ?? ''; ?>" /><br/>
			 <input type="submit" name="search" value="Submit"/>
		</form>

<?php if(isset($_REQUEST["search_string_result"])) {
        echo "search by :" . $_REQUEST["search_string_result"];
        
} ?>


<?php if(isset($_REQUEST["search_user"])) {
        //$search_user = serialize($_REQUEST["search_user"]);
        $search_user =  $_SESSION['search_user'];
        //print_r($search_user); die();

        if(count($search_user) > 0){ ?>

	<table border="1">
		<tr> 
			<th> ID </th>
			<th> Name </th> 
			<th> Email </th>
                     <th> password </th>
                     <th> gender </th>
                     <th> image </th>
			<th colspan="2"> Action </th>
              </tr>
             <?php foreach($search_user as  $user ){ ?>
		<tr>
			<td> <?php echo $user["id"]; ?> </td>
			<td> <?php echo str_replace($_REQUEST["search_string_result"] , '<span style="color:#ff0000;">' . $_REQUEST["search_string_result"]  .'</span>' , $user["username"]); ?> </td>
                     <td> <?php echo str_replace($_REQUEST["search_string_result"] , '<span style="color:##ff0000;">' . $_REQUEST["search_string_result"]  .'</span>' , $user["email"]); ?> </td>
                     <td> <?php echo md5($user["password"]); ?> </td>
                     <td> <?php echo $user["gender"]; ?> </td>
			<td> <img src="<?php echo $file_path.$user["image"]; ?>" width="50px" height="30px" /> </a> </td>
			<td> <a href="<?php echo "../view/edit.php?userid=" . $user["id"]; ?>" > Edit </td>
			<td> <a href="<?php echo "../controller/delete.php?userid=" . $user["id"]; ?>" > Delete </td>
		</tr>
             <?php } ?>
       </table>
       
<?php }  

 }else{ ?>
        
       <table border="1">
		<tr> 
			<th> ID </th>
			<th>Name </th> 
			<th>Email </th>
                     <th> password </th>
                     <th> gender </th>
                     <th> image </th>
			<th colspan="2"> Action </th>
              </tr>
             <?php foreach($row as $users => $user ){ ?>
		<tr>
			<td> <?php echo $user["id"]; ?> </td>
			<td> <?php echo $user["username"]; ?> </td>
                     <td> <?php echo $user["email"]; ?> </td>
                     <td> <?php echo md5($user["password"]); ?> </td>
                     <td> <?php echo $user["gender"]; ?> </td>
			<td> <img src="<?php echo $file_path.$user["image"]; ?>" width="50px" height="30px" /> </a> </td>
			<td> <a href="<?php echo "../view/edit.php?userid=" . $user["id"]; ?>" > Edit </td>
			<td> <a href="<?php echo "../controller/delete.php?userid=" . $user["id"]; ?>" > Delete </td>
		</tr>
             <?php } ?>
       </table>

<?php }
 
?>       
	<br/>
	<br/>
	
</body>
</html>