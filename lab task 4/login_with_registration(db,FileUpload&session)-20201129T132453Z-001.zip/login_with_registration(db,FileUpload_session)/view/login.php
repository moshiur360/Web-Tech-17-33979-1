<?php 
if(isset($_REQUEST["msg"])){

    $msg = $_REQUEST["msg"];
    
    if($msg == "regtration-completed"){
           echo $msg;
    }elseif ($msg == "field-empty") {
           echo $msg;
    }elseif ($msg == "invalid") {
           echo $msg;
    }elseif ($msg == "invalid-creadiantial") {
		   echo $msg;
	}elseif ($msg == "you-loged_out") {
		   echo $msg;
	}elseif ($msg == "you-are-not-login") {
		echo $msg;
	}else{
		echo $msg;
	}
}

?>


<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
</head>
<a href="../view/dashboard.php">HOME </a>
<body>
	<fieldset>
	<legend>LOGIN</legend>
		<form method="post" action="../controller/login_check.php">
			User Name: <input type="text" name="username"/><br/>
			Password  : <input type="password" name="password"/><br/>
			<input type="submit" name="submit" value="Submit"/>
		</form>
	</fieldset>
	if you are not registration goto <a href="../view/rege.php">regirstration </a>
</body>
</html>