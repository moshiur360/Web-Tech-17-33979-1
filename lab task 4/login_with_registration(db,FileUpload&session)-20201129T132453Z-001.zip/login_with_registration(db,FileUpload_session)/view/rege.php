<?php 

if(isset($_REQUEST["msg"])){

    $msg = $_REQUEST["msg"];
    
    if($msg == "fild-empty"){
        echo $msg;
    }elseif ($msg == "file-not-found") {
		echo $msg;
	}elseif($msg == "is-not-a-valid-file"){
		echo $msg;
    }else {
        echo $msg;
    }
    
    
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body>
<a href="../view/dashboard.php">HOME </a> 
	<fieldset>
	<legend>Registration</legend>
		<form method="post" action="../controller/rege_check.php" enctype="multipart/form-data">
            User Name : <input type="text" name="username"/><br/>
            Email     : <input type="text" name="email"/><br/>
			Password  : <input type="password" name="password"/><br/>
			Image     : <input type="file" name="image"/> (must be a jpg file) <br/> 
			Gender    : 
			<input type="radio" name="gender" value="male"/>Male 
			<input type="radio" name="gender" value="female"/>Female 
			<input type="radio" name="gender" value="other"/>Other <br/>
			<input type="submit" name="submit" value="Submit"/>
		</form>
	</fieldset>
	if you are a registered member then goto <a href="../view/login.php">login </a> 
</body>
</html>