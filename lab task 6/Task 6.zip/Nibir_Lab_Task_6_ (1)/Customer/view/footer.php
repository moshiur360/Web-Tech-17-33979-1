<!DOCTYPE html>
<html>
<head>
	<title>Footer</title>
</head>
<body>
	<h4>Contact Us</h4>
	<b>Email:</b>atrms@outlook.com <br>
	<b>Phone:</b>+99605534 <br>
	<b>Address:</b>Nikunja-2,Dhaka <br>


</body>
</html>