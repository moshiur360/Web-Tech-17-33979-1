
<!DOCTYPE html>
<html>
<head>
	<title>Centering a form</title>
</head>
<body>
	<div class="form">
    <h1>please registration</h1>

    <a href="login.php">Login</a>
    <a href="index.html">Home</a>

    <form action="../controller/regv.php" method="post"><pre>
  
<h2> User Name: </h2>
<input type="text" name="uname"><br/>
<h2>Password: </h2>
<input type="password" name="pass"><br/>
<h2>Confirm Password: </h2>
<input type="password" name="confpass"><br/>
<h2>E-Mail: </h2>
<input type="email" name="email"><br/>
<input type="submit" name="sbt" value="submit" />
</pre>
     </form> </br>


   </div>
</body>
</html>




<style type="text/css">
	.form {
		margin: 0 auto;
		width: 210px;
	}

	.form label{
		display: inline-block;
		text-align: right;
		float: left;
	}

    .form h1{
		display: inline-block;
		text-align: center;
		float: left;
	}

    .form h2{
		display: inline-block;
		text-align: left;
		float: left;
	}

	.form input{
		display: inline-block;
		text-align: left;
		float: right;
	}
</style>
  